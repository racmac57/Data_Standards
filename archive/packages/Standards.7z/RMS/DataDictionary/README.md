# RMS DataDictionary

This folder stores the **RMS export** data dictionary artifacts: schemas, value domains, defaults, and supporting scripts.

## Layout

- `current/schema/`: schemas + field maps (JSON)
- `current/domains/`: allowed value sets / enumerations (JSON)
- `current/defaults/`: default rules (JSON)
- `archive/`: dated snapshots
- `templates/`: reusable templates
- `scripts/`: helper scripts


