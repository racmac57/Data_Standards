# RMS DataDictionary (status)

## Current schema artifacts

Located in `current/schema/`:

- (none checked in yet)


