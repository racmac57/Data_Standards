# Changelog (RMS DataDictionary)

## 2025-12-15

- Standardized folder scaffolding (`current/schema|domains|defaults`, `archive`, `templates`, `scripts`).


