# Changelog (CAD_RMS DataDictionary)

## 2025-12-15

- Added cross-system DataDictionary folder scaffolding.
- Copied cross-system field maps into `current/schema/`.


