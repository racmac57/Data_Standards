# CAD_RMS DataDictionary

This folder stores **cross-system** (CAD ↔ RMS) rules and mappings.

## Layout

- `current/schema/`: cross-system field maps and merge rules (JSON)
- `archive/`: dated snapshots
- `scripts/`: helper scripts


