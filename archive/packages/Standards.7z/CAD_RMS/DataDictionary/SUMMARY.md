# CAD_RMS DataDictionary (status)

## Current schema artifacts

Located in `current/schema/`:

- `cad_to_rms_field_map.json`
- `rms_to_cad_field_map.json`


