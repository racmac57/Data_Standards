# CAD DataDictionary (status)

## Current schema artifacts

Located in `current/schema/`:

- `cad_to_rms_field_map.json`
- `rms_to_cad_field_map.json`
- `cad_export_field_definitions.md`


