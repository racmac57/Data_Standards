# CAD DataDictionary

This folder stores the **CAD export** data dictionary artifacts: schemas, value domains, defaults, and supporting scripts.

## CAD export field definitions

The draft “data dictionary style” definitions (formats, derivations, allowed values, validations) for the CAD export live at:

- `current/schema/cad_export_field_definitions.md`

## Layout

- `current/schema/`: schemas + field maps (JSON)
- `current/domains/`: allowed value sets / enumerations (JSON)
- `current/defaults/`: default rules (JSON)
- `archive/`: dated snapshots
- `templates/`: reusable templates
- `scripts/`: helper scripts
