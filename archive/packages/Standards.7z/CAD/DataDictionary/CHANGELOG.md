# Changelog (CAD DataDictionary)

## 2025-12-15

- Standardized folder scaffolding (`current/schema|domains|defaults`, `archive`, `templates`, `scripts`).
- Confirmed presence of cross-system field maps under `current/schema/`.

## 2025-12-17

- Added draft CAD export field definitions / validation rules:
  - `current/schema/cad_export_field_definitions.md`
